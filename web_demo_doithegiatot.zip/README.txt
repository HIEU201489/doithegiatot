Hướng dẫn nhanh - Demo Nạp Thẻ (doithegiatot.com)
============================================

File trong package:
- index.html       : Form UI (POST -> process.php)
- process.php      : Xử lý form, gửi JSON POST tới https://doithegiatot.com/api/card
- cardrate.php     : Ví dụ GET chiết khấu https://doithegiatot.com/api/cardrate?apikey={apikey}
- config.php       : Chứa api key. Thay 'YOUR_API_KEY_HERE' bằng API Key thật
- README.txt       : file này

Hướng dẫn chạy:
1) Giải nén web_demo_doithegiatot.zip vào thư mục web server (ví dụ: /var/www/html/demo).
2) Đảm bảo PHP và cURL extension đã bật trên server.
3) Chỉnh file config.php: sửa 'apikey' => 'YOUR_API_KEY_HERE' thành API Key của bạn.
4) Mở trình duyệt tới index.html, nhập thông tin thẻ và gửi.
5) Kết quả API sẽ hiển thị ở process.php.

Ghi chú bảo mật:
- KHÔNG lưu API Key công khai nơi không an toàn.
- Trong môi trường production, cần kiểm tra đầu vào, dùng HTTPS, và xử lý lỗi/cảnh báo phù hợp.
