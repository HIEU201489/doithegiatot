<?php
// cardrate.php - ví dụ lấy chiết khấu bằng GET
$config = include __DIR__ . '/config.php';
$apikey = $config['apikey'] ?? '';

if ($apikey === '' || $apikey === 'YOUR_API_KEY_HERE') {
    echo '<p>Vui lòng cập nhật <code>config.php</code> với API Key để xem chiết khấu.</p>';
    exit;
}

$url = 'https://doithegiatot.com/api/cardrate?apikey=' . urlencode($apikey);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_TIMEOUT, 20);
$response = curl_exec($ch);
$err = curl_error($ch);
curl_close($ch);

echo '<h1>Chiết khấu thẻ (cardrate)</h1>';
if ($err) {
    echo '<p style="color:red">cURL error: ' . htmlspecialchars($err) . '</p>';
} else {
    $json = json_decode($response, true);
    if ($json === null) {
        echo '<pre>' . htmlspecialchars($response) . '</pre>';
    } else {
        echo '<pre>' . htmlspecialchars(json_encode($json, JSON_PRETTY_PRINT)) . '</pre>';
    }
}
echo '<p><a href="index.html">&laquo; Quay lại</a></p>';
