<?php
// config.php - cấu hình API
// Thay YOUR_API_KEY_HERE bằng API Key thật của bạn
return [
    'apikey' => 'YOUR_API_KEY_HERE',
    // Nếu muốn dùng callback, chỉnh webhook URL tương ứng ở đây (không bắt buộc)
    'webhook' => ''
];
