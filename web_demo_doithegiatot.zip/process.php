<?php
// process.php - nhận form và gửi JSON POST tới https://doithegiatot.com/api/card
$config = include __DIR__ . '/config.php';
$apikey = $config['apikey'] ?? '';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo 'Method not allowed'; exit;
}

$pin = isset($_POST['Pin']) ? trim($_POST['Pin']) : '';
$seri = isset($_POST['Seri']) ? trim($_POST['Seri']) : '';
$cardType = isset($_POST['CardType']) ? intval($_POST['CardType']) : 0;
$cardValue = isset($_POST['CardValue']) ? intval($_POST['CardValue']) : 0;
$requestid = isset($_POST['requestid']) ? trim($_POST['requestid']) : '';

if ($apikey === '' || $apikey === 'YOUR_API_KEY_HERE') {
    echo '<h2>Lưu ý:</h2><p>Vui lòng chỉnh file <code>config.php</code> và điền API Key thật trước khi dùng.</p>';
    echo '<p>Hiện dữ liệu gửi (không gửi tới API):</p><pre>' . htmlspecialchars(json_encode(compact('apikey','pin','seri','cardType','cardValue','requestid'), JSON_PRETTY_PRINT)) . '</pre>';
    exit;
}

// Build payload according to PDF spec
$payload = [
    'ApiKey' => $apikey,
    'Pin' => $pin,
    'Seri' => $seri,
    'CardType' => $cardType,
    'CardValue' => $cardValue,
    'requestid' => $requestid
];

$url = 'https://doithegiatot.com/api/card';

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
curl_setopt($ch, CURLOPT_TIMEOUT, 30);

// If you have TLS issues on local dev, you might need to disable peer verify (not recommended in production)
// curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

$response = curl_exec($ch);
$err = curl_error($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

echo '<h2>Request JSON</h2><pre>' . htmlspecialchars(json_encode($payload, JSON_PRETTY_PRINT)) . '</pre>';
echo '<h2>API Response (HTTP ' . htmlspecialchars($http_code) . ')</h2>';
if ($err) {
    echo '<p style="color:red">cURL error: ' . htmlspecialchars($err) . '</p>';
} else {
    // try pretty print
    $json = json_decode($response, true);
    if ($json === null) {
        echo '<pre>' . htmlspecialchars($response) . '</pre>';
    } else {
        echo '<pre>' . htmlspecialchars(json_encode($json, JSON_PRETTY_PRINT)) . '</pre>';
    }
}

echo '<p><a href="index.html">&laquo; Quay lại</a></p>';
